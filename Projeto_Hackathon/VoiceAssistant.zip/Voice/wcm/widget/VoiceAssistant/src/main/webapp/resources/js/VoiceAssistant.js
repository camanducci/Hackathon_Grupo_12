var MyWidget = SuperWidget.extend({
    message: null,

    init: function () {
    	carregaCabecalho();
    	habilitaMicrofone();
    	
    },

    bindings: {

    },

});